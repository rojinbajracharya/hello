# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

#Dessert = MEAL_ID,  Dessert_name, Dessert_description, 

desserts = [{:title => 'CHOCOLATE CAKE', :description => 'CHOCOLATE, all purpose flower, nuts, butter', :image => "CAKE.JPG"},
          {:title => 'BANANA CAKE', :description => 'BANANA, all purpose flour, nuts, sugar,butter', :image => "bananaCake.JPG"},
          {:title => 'PUMKIN CUSTARD', :description => 'PUMKIN, eeg, sugar, coconut milk', :image => "PumkinCustard.JPG"},
          {:title => 'TONG YOT', :description => 'EGG YOLK Blanded with wheat, cooked in sugar syrup', :image => "TONG_YOD.JPG"},
          {:title => 'TONG YIP', :description => 'EGG YOLK Blanded with wheat, cooked in sugar syrup', :image => "TONGYIP.JPG"},
          
      ]

desserts.each do |dessert|
  Desserts.create!(dessert)
end

mains = [{:title => 'Grilled Meat', :description => 'MEAT OF YOUR CHOICE', :image => "GRILL_CHICKEN.JPG"},
          {:title => 'Pad Thai', :description => 'STIRED_FRY_NOODLE, CHOICED OF MEAT,TOFU,GREEN ONION, BEAN SPROSE', :image => "PADTHAI.JPG"},
          {:title => 'Green Curry', :description => 'GREEN CURRY PAST, MEAT OF YOUR CHOICES, VETGETABLE, EGG PLANT, SALT, COCONUT MILK', :image => "GREEN_CURRY.JPG"},
          {:title => 'Yellow Curry', :description => 'CURRY POWDER, CURRY PAST,MEAT OF YOUR CHOICES,POTATOS, SALT, SUGER, COCONUT MILK', :image => "YELLOW_CURRY.JPG"},
          {:title => 'Musaman Curry', :description => 'CURRY PAST,  MEAT OF YOUR CHOICES, ONION, POTATO, RED CHILY, COCONUT MILK', :image => "MASA_MAN.JPG"},
          {:title => 'Fry Rice', :description => 'MEAT OF YOUR CHOICES, GREEN ONION, GREEN BEANS, TOMATO, EGG', :image => "FRI_RICE.JPG"},
          {:title => 'Stir Fry Noodle', :description => 'MEAT OF YOUR CHOICES, WHITE NOODLE, SOY SOURCE, SUGAR, VETGETABLE', :image => "Sate.JPG"},
          
      ]

mains.each do |main|
  Mains.create!(main)
end

appitizers = [{:title => 'Grill Sate', :description => 'MEAT OF YOUR CHOICE, CURRY POWDER, SALT, SUGER, COCONUT MILK, CHOPED NUT, CUCUMBER SALAD SIDE DISH', :image => "Grilled_Chicken.JPG"},
          {:title => 'Egg Role', :description => 'MIXED VEGETABLE, NOODLE, YOUR CHOICES OF MEAT', :image => "Egg_Role.JPG"},
          {:title => 'Papaya Salad', :description => 'GREEN PAPAYA, DRY_SHRIM, NUTS, SUGER, SULT, LEMMON JUICE', :image => "PAPAYA_SALAD.JPG"},
          {:title => 'Currry Puff', :description => 'GROUND MEAT OF YOUR CHOICE,  CURRY POWDER, MIX WITH CHOPED YAM, ONION,  SALT, SUGAR, PEPPER, WRAPED WITH ALL PURPOSE FLOWER, DEEP FRY', :image => "CURRY_PUFF.JPG"},
          {:title => 'Tomyum Soup', :description => 'MEAT OF YOUR CHOICE, LEMMON GRASS, KALANKA ROOT, LEMMON JOICE, MUSHROOM, SALT, OR FISH SOURCE', :image => "TOM_YUM.JPG"},
          {:title => 'Wanton Soup', :description => 'WONTON_SHEET STUFF WITH YOUR CHOICES OF MEAT,VETGETABLE', :image => "wanton_soup.JPG"},          
      ]

appitizers.each do |appitizer|
  Appitizers.create!(appitizer)
end