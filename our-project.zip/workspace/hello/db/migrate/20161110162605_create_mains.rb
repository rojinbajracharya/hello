class CreateMains < ActiveRecord::Migration
  def change
    create_table 'mains' do |t|
      t.string :title
      t.string :description
      t.string :image
      # Add fields that let Rails automatically keep track
      # of when movies are added or modified:
      t.timestamps
    end
  end
  
  def down
    drop_table "mains"
  end
end
