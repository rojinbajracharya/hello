class Review < ActiveRecord::Base
    
end
class Review < ActiveRecord::Base
end
