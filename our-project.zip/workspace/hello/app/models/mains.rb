class Mains< ActiveRecord::Base
end
