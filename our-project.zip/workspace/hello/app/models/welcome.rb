class WelcomeController< ActiveRecord::Base
end
