class Appitizers< ActiveRecord::Base
end
